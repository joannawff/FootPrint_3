test('Marquee Exist', function() {
    ok($.isFunction( $.fn.marquee ), 'Marquee function is exist.');
});